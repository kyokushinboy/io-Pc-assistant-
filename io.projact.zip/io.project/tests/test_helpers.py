import importlib
import sys
import os

# Ensure project root is on sys.path
PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

import importlib.util

# Load the assistant module from io/io.py by path to avoid clashing with stdlib 'io'
PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
IO_PATH = os.path.join(PROJECT_ROOT, 'io', 'io.py')
spec = importlib.util.spec_from_file_location('assist_io', IO_PATH)
assert spec is not None, f"Could not create module spec for {IO_PATH}"
io_module = importlib.util.module_from_spec(spec)
loader = getattr(spec, 'loader', None)
assert loader is not None, f"Could not load module loader for {IO_PATH}"
loader.exec_module(io_module)


def test_detect_emotion_happy():
    assert io_module.detect_emotion('من خیلی خوشحال هستم') == 'happy'


def test_detect_emotion_sad():
    assert io_module.detect_emotion('امروز غمگینم و خسته') == 'sad'


def test_detect_emotion_none():
    assert io_module.detect_emotion('این یک جمله عادی است بدون احساس خاص') is None
