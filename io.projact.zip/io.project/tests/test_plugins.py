import importlib
import sys
import types
import os

PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
if PROJECT_ROOT not in sys.path:
    sys.path.insert(0, PROJECT_ROOT)

# Import the assistant module
import importlib.util

# Load assistant module by path
PROJECT_ROOT = os.path.dirname(os.path.dirname(__file__))
IO_PATH = os.path.join(PROJECT_ROOT, 'io', 'io.py')
from importlib.machinery import SourceFileLoader
# Use SourceFileLoader so a loader is always available, then create a spec from that loader.
loader = SourceFileLoader('assist_io', IO_PATH)
spec = importlib.util.spec_from_loader('assist_io', loader)
if spec is None:
    raise ImportError(f"Could not create module spec for {IO_PATH}")
io_module = importlib.util.module_from_spec(spec)
loader.exec_module(io_module)


def test_plugin_dispatch_handles_query(monkeypatch):
    # Create a fake plugin module
    mod = types.SimpleNamespace()
    mod.__name__ = 'plugins.mock_plugin'
    def can_handle(q):
        return 'mockme' in q
    def handle(q):
        # Simulate doing something and return True to indicate handled
        return True
    mod.can_handle = can_handle
    mod.handle = handle

    # Insert into PLUGINS temporarily
    original_plugins = list(io_module.PLUGINS)
    io_module.PLUGINS.insert(0, mod)

    try:
        # Simulate a query that should be handled by the plugin
        query = 'please mockme now'
        handled = False
        for m in io_module.PLUGINS:
            if hasattr(m, 'can_handle') and m.can_handle(query):
                res = m.handle(query)
                handled = bool(res)
                break
        assert handled is True
    finally:
        # Restore plugins
        io_module.PLUGINS[:] = original_plugins
