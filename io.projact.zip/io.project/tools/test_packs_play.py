import importlib.util, os, json, time
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
# Load config
cfg_path = os.path.join(ROOT,'config','notifications.json')
with open(cfg_path,'r',encoding='utf-8') as f:
    cfg = json.load(f)
for pack in ['modern','minimal','retro']:
    cfg['sound_pack'] = pack
    with open(cfg_path,'w',encoding='utf-8') as f:
        json.dump(cfg,f,ensure_ascii=False,indent=2)
    print('\nSet pack to',pack)
    # load notification module and play an info notify
    path = os.path.join(ROOT,'io','notification.py')
    spec = importlib.util.spec_from_file_location('local_notification', path)
    assert spec is not None, f"Could not create ModuleSpec for {path}"
    mod = importlib.util.module_from_spec(spec)
    loader = spec.loader
    assert loader is not None, f"Could not get loader for {path}"
    loader.exec_module(mod)
    mod.set_speak_callable(lambda t,**k: print('[SPEAK]',t))
    mod.notify({'title':'packtest','message':'pack test','level':'info'})
    time.sleep(1)
print('done')
